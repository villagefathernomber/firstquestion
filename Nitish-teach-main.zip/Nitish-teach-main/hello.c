#include<stdio.h>
int main(){
printf("hello,Github,this is my first c program\n");
return 0;
}
